# 746. Min Cost Climbing Stairs

cost = [10,15,20]

count = 0
for i in range(0,len(cost)):
    current = cost[i]
    first = cost[i+1]
 
    second = cost [i+2]

if cost[3]:
    print('there is 3rd element')
else:
    print('no 3rd element')

# def minCost(cost):
#     for i in range(len(cost)):

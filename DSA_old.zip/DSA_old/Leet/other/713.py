
#! 713 - Subarray Product Lesst Than K (medium)
"""
Given an array of integers nums and an integer k, return the number of contiguous subarrays where the product of all the elements in the subarray is strictly less than k.
"""

nums = [10, 5, 2, 6]
k = 100


arr = nums
start = 0
mult = 0
count = 0

for end in range(len(nums)):
    mult = 

    if s:
        first = arr[start] 

        count += 1

        start += 1

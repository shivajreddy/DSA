s1 = "ab"
s2 = "eidboaooab"


def check_inclusion(s1: str, s2: str) -> bool:
  hashmap = {}


print(check_inclusion(s1,s2))



def maxArea(height):

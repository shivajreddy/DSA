

# class Enumerate(iter, start):

#   def __init__(self):
#     self.start = start
#     self.iter = iter

  
chars = ['a','b','c','d', 'z', 'z', 'x', 'y']

for c,n in enumerate(chars,21):
  print(c,n, sep='')
  print(c,n)
  


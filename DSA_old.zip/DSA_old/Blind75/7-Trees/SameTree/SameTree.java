public class SameTree {
  Solution s = new Solution();
}

class Solution {

}
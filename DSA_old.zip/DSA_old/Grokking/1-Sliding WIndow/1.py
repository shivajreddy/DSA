arr = [2, 1, 5, 1, 3, 2]
s = 2


start = 0
result = 0
_sum = 0

for end in range(len(arr)):

    _sum += arr[end]

    # window shift starts here
    if end >= s-1:
        if _sum >=

        _sum -= arr[start]
        start += 1


string="catfoxcat"
words=["cat", "fox"]



